---
title: [Skill Name]
domain: [e.g. Backend, UI, DevOps]
tags: [tag1, tag2]
---

# [Skill Name]

## Best Practice
(Describe the best practice pattern here)

## Snippet
```
(Paste your code snippet here)
```
