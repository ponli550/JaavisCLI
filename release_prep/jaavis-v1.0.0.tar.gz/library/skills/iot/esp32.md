---
name: esp32
description: "better then ArduinoUno"
grade: B
tags: [tag1, tag2]
pros:
  - "Easy to use"
cons:
  - "fragile"
---

# esp32

## Best Practice
(Describe the best practice pattern here)

## Snippet
```
(Paste your code snippet here)
```
