---
title: [Skill Name]
domain: [e.g. Backend, UI, DevOps]
tags: [tag1, tag2]
---

# Problem Context
*Describe the recurring problem this skill solves. Why do we need this?*

# The Solution (Pattern)
*High-level explanation of the approach.*

# One-Army Snippet
*The copy-paste ready code or configuration. Make this generic (remove project-specific names).*

```[language]
// Code here
```

# Implementation Notes
*   **Dependencies**: What packages are needed?
*   **Gotchas**: What to watch out for?
