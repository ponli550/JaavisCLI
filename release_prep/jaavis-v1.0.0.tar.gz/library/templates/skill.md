---
name: [Skill Name]
description: "[Description]"
grade: [Grade]
tags: [tag1, tag2]
pros:
[Pros List]
cons:
[Cons List]
---

# [Skill Name]

## Best Practice
(Describe the best practice pattern here)

## Snippet
```
(Paste your code snippet here)
```
